$(document).ready(function () {
  $(".owl-carousel").owlCarousel({
    items: 1,
    loop: true,
    autoplay: true,
    autoplayTimeout: 4000,
    transitionStyle: "fade",
    animateIn: "fadeIn",
    animateOut: "fadeOut",
  });
  // });

  // // Hamberger Menu
  // const hambergur = document.querySelector(".hambarger_nav");
  // const hambergurClose = document.querySelector(".hambarger_nav > i");

  // const nave_menu = document.querySelector(".nav_menu");
  // hambergur.addEventListener("click", () => {
  //   nave_menu.classList.toggle("side_nav");
  //   hambergur.classList.toggle("nav_open");
  //   hambergurClose.classList.toggle("fa-times");
});
